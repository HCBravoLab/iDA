library(testthat)
library(iDA)


test_check("iDA")
